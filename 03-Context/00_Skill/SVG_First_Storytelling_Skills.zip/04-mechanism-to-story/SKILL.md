---
name: mechanism-to-story
summary: Convert complex mechanisms into truthful, understandable, causal visual narratives.
description: Use when an unfamiliar technical, physical, scientific, business or software process needs to be understood before storyboarding, animating or presenting it. Extracts source truths, events, audiences' learning sequence, uncertainties, narrative beats and visual-mechanic handoff.
---

# Skill 04 — Mechanism-to-Story Translation

## Purpose
Understand **what happens, why it happens and what changes**, then turn it into an accurate, visualizable event sequence. Do not confuse a visually impressive shot with a correct explanation.

**Unit of work:** One coherent mechanism and its chronological (or explicitly simultaneous) causal events.  
**Primary output:** An event/beat sheet ready for `svg-mechanic-storyboarding` (Skill 06).  
**Principle:** *Correct mechanics first; visual taste later.*

## When to trigger
- The user shares source materials, client messages or product specs and asks what a process does or how to animate it.
- The user is new to a subject and needs a layered, chronological explanation.
- Existing visual frames are confusing or technically wrong.
- A project has a feature list but no coherent story.
- The user wants a client to verify their understanding before production.

Works across industrial films, medical explanations, educational video, product demos, UX process stories, business systems, documentaries and science communication.

## Inputs
- At least one source of factual meaning: direct client explanation, spec, photo, CAD, workflow, log/report or video.
- Intended audience or safe default: curious non-expert.
- Optional: duration, desired takeaway, visual references, constraints, client feedback and available real evidence.

Do **not** guess authoritative component geometry, dimensions, flow or sensor placement from a decorative illustration. If uncertain, ask a focused question only when it blocks a truthful explanation; otherwise label the assumption.

## Source discipline
Before storytelling, distinguish:
- **Fact (F):** Clearly described by the client or authoritative source; attribute it.
- **Interpretation (I):** A plausible explanation consistent with sources but not directly confirmed.
- **Creative proposal (P):** A way of *showing* a process, not a technical claim.
- **Open question (Q):** Information requiring confirmation to avoid a materially wrong depiction.

Create a short constraint ledger. Prioritize: **identities, counts, sizes, coordinate viewpoint, motions, direction, sequence, simultaneity, signal paths, operating modes, data semantics, source/version attribution**.

Never silently merge inconsistent claims. Point out conflicts and request verification as needed.

## Method: 9 operations

### 1. State the core mechanism in one sentence
Use causal language: **actor → action → target → response → result**. Avoid feature lists.

Example pattern: `A [thing] acts on [thing], receives/causes [response], and uses that to determine/change [result].`

### 2. Define the system and its reference frame
Identify actors, environment, inputs, outputs, component roles and boundaries. State which way is down, forward, clockwise, flow direction or data flow **as viewed from a named position**. Differentiate stationary camera from rotating object.

### 3. Identify what is truly observable
Distinguish:
- **Literal physical action:** real moving mechanism, fluid, surface contact.
- **Hidden physics:** sound, force, pressure or electromagnetic signal; requires a *metaphoric* visual.
- **Measured data:** interpreted points, paths, maps or values; not photography.
- **Actual evidence:** recorded output, real field report or footage with source/model identity.

### 4. Decompose into atomic causal events
Break the principle into minimal meaningful state changes, such as:
`initial environment → one action → one response → first measured consequence → repeated cycles → accumulated result`.

Use this table when helpful:

| Event | Before | Actor/action | Target/response | After | Certainty |
|---|---|---|---|---|---|
| E01 | … | … | … | … | F/I/P/Q |

A change in *how we teach* a mechanism is not necessarily a change in *how it physically operates*. Mark parallel/simultaneous actions explicitly.

### 5. Find the minimum audience learning chain
Order events so each one answers a viewer question and prepares the next:
1. Where are we / why is it difficult?
2. What is the smallest understandable mechanism?
3. What happens once?
4. What happens as it repeats or accumulates?
5. What new capability or output results?
6. Where is the evidence or practical value?

Do not introduce advanced claims before the viewer can explain the simplest mechanism.

### 6. Translate events into visualizable states
For each event, suggest a representation: cutaway, simple 2D or SVG schematic, actor motion, diagram, waveform, point cloud, comparison, realistic object, stylized data or real evidence. Specify **what the viewer must see**, not yet the detailed cinematography.

A glowing wave does not mean a real wave emits visible light. A heat map is not the natural color of an object. Label these as representations in the captions/notes.

### 7. Create a beat sheet
For every beat include:
- **Audience question:** What does the viewer need to understand?
- **Before state:** What has already been established?
- **Action/response:** Exact causal chain.
- **Visual proof:** What must be visible to make it clear?
- **Audience takeaway:** One short statement.
- **Transition:** Why move to the next beat?
- **Accuracy concerns:** What must be confirmed or must not be implied?
- **Duration:** Only if a runtime exists.

### 8. Run the misconception audit
Before passing to visuals, check:
- Does the echo return to its originating receiver (when applicable)?
- Are all physically connected pieces moving correctly together?
- Do arrows reflect the correct physical and coordinate directions?
- Did we confuse *nominal/reference* with *actual/measured* geometry?
- Did we confuse simultaneous sections with sequential on/off operating modes?
- Did we conflate different properties extracted from the same measurement?
- Does a map falsely look like literal photography?
- Did we imply live processing when it occurs only after acquisition/retrieval?
- Is real evidence attributed to the right run, version or device?
- Does a diagram imply exact hardware geometry without source approval?

### 9. Hand off to the SVG skill
Deliver **event IDs, causal states, consistent reference frame, component roles, accuracy rules, visual conventions, questions and proposed panel count**. Skill 06 then creates the fast static vector panels.

## Required output contract
**A. Mechanism in plain language:** One-sentence explanation plus minimum supporting definitions.

**B. Mechanism ledger:** Components, environment, input, action, response, output, reference directions and evidence status.

**C. Causal events:** Chronological events, with explicitly simultaneous events if needed.

**D. Narrative beats:** What audience asks, sees, learns and how each beat leads into the next.

**E. Source/uncertainty note:** Facts, proposals and blocking confirmation questions.

**F. SVG handoff brief:** One line per recommended static state and its intended meaning.

## Approval gate
Pass to Skill 06 only when:
- The physical/logical mechanism makes sense in a plain-language teach-back.
- Every beat has exactly one main causal lesson.
- Technical directions and identities are consistent.
- No unsupported engineering claim is presented as verified.
- Unresolved questions are visible, and the user knows which affect production.

## Anti-patterns
- Feature lists presented as a story.
- Camera moves and dramatic finishing planned before the mechanics are understood.
- A polished render used as evidence of engineering accuracy.
- Decorative arrows mistaken for actual directions of energy/flow.
- One data property magically transforming into a separate one.
- Client corrections changing already approved, unrelated beats.

## Fast mode
If user asks for a simple explanation, answer in **five statements**: what exists → what acts → what responds → what changes → how to show it. If asked for a full animation structure, expand those statements into beat IDs and hand off to Skill 06.
