# SVG-First Mechanism Storytelling — Portable AI Skills

Extracted and generalized from an engineering/product animation workflow. These are **two independent AI skill instructions**; they do not contain any client-specific facts and can be reused in another project or conversation.

## Responsibilities

| Skill | Answers | Produces |
|---|---|---|
| `04-mechanism-to-story` | **What actually happens, and in what causal order should the audience learn it?** | Plain-language mechanism, source/assumption register, atomic events, story beats, accuracy checklist. |
| `06-svg-mechanic-storyboarding` | **How do we show each important event clearly, fast, and make it easy for a client to correct?** | Independent SVG panels (no text inside), captions outside, client-review questions, optional PNG/ZIP files. |

## Reusable high-speed loop
1. Gather client descriptions, diagrams, photos and factual constraints.
2. Run **04** to explain the causal mechanics in simple terms and identify uncertainties.
3. Hand off to **06** to create 3–5 simple SVG panels **directly in the chat**, each with its own caption.
4. Show to client; comments are attached to individual panels in Padlet/Miro/etc.
5. Correct only affected panels; preserve approved information.
6. Once the *mechanics* are approved, proceed separately to look-development, product-accurate 3D, camera animation and final render.

## Quick activation prompts

**Mechanism**: `Use the Mechanism-to-Story skill. Read this client's explanation. First identify verified facts, components, reference directions, actions and results; then explain the mechanism in simple terms. Produce a causal event sequence and visual story beats. Mark assumptions; do not yet polish or render anything.`

**SVG:** `Use the SVG-First Visual Mechanic Storyboarding skill for the approved story beats. Produce 3–5 small, clear SVG panels directly in chat, no text inside any frame. After each SVG, add a standalone client-facing caption describing exactly what happens and why. Keep the component geometry and physical directions consistent. No HTML, images or final-render work.`

**Revision:** `The client says Panel S03-P02 is wrong because [issue]. Identify whether this alters the mechanism or only the depiction. Update only affected SVGs and related captions; preserve all other approved panels.`

## Suggested use
Provide the two `SKILL.md` folders to a compatible AI agent skill system, or upload/paste the relevant markdown in a ChatGPT session. Automatic installation is *not* performed by this ZIP; actual discovery depends on the target agent's skill support.

## Example
`examples/pulse_echo/` contains a small three-state conceptual example demonstrating how one action becomes three SVG panels with captions. It is only an explanation of format, not a verified product design.
