# Tiny example: pulse → reflection → measurement

This is a **generic educational demonstration**, not a technical drawing or simulation of a particular product.

## Mechanism from Skill 04
- **Existing state:** A sensor faces a boundary it cannot see optically.
- **Cause:** The sensor emits an ultrasonic pulse into the medium.
- **Response:** The boundary reflects some energy back to the sensor.
- **Measurement:** After the return, the device can use the measured travel time to estimate distance when the signal speed is known or corrected.
- **Caution:** The glowing arcs are merely a stylized depiction of sound.

## Skill 06 storyboard

**Panel 1 — Send the pulse**: A single short ultrasonic pulse travels outward toward the boundary. The glowing blue wavefront is a schematic visualization of acoustic energy, not literal light.

**Panel 2 — Receive the echo**: The pulse meets the boundary and a reflected response travels back to the originating sensor. It is important to depict the return, not just a one-way beam.

**Panel 3 — Establish a measurement**: After the return, a point appears on the boundary to symbolize the measured distance in that direction. This is derived data, not a camera image of the surface.

Each SVG has NO text inside the frame. Each caption stands outside.
