---
name: svg-mechanic-storyboarding
summary: Draw technical/story mechanics as fast, reviewable SVG frames with captions outside each image.
description: Use when the user asks for story-mechanic SVG panels, chat-native visual explanations, Padlet-ready diagrams, or incremental client reviews of a physical, scientific, conceptual or software mechanism. Works from a causal sequence (ideally from mechanism-to-story) and produces editable vector drawings, captions, corrections and production handoff.
---

# Skill 06 — SVG-First Visual Mechanic Storyboarding

## Mission
Translate **verified/provisionally understood causal events** into minimal, readable SVG panels that a client can inspect and correct immediately. The SVGs explain **what happens**, not what the final film must look like.

**Speed is deliberate:** Direct SVG beats a photoreal render for resolving geometry, sequence, flow, measurement and cause/effect. Keep the rapid feedback loop alive.

## Defaults
- **SVG in the chat first.** No external webpage, HTML, storyboard tool or file generation unless the user needs one.
- **No text inside SVG frames.** Put captions, titles, timestamps and warnings *outside* the drawing. Exception only if user explicitly requests image labels or supplied branding.
- **One principal idea per panel.** Prefer 3–5 panels for one section, but follow actual causal states, not fixed quotas.
- **Simple vector geometry.** Use rectangles, circles, paths, arrows, line patterns and minimal shading. Avoid CGI finishing, elaborate atmosphere and realistic textures at this stage.
- **Stable continuity.** Match object identity, proportions, location and logical orientation between frames except when a camera change is deliberate.
- **Separate factual constraints from illustrative choices.** When layout/shape is conceptual, the caption must say so.

## Inputs
Use the output of Skill 04 or derive the minimum mechanism from the user's supplied explanation:
1. Event order and what causes each event.
2. Names/identities and relationships of components.
3. Direction, coordinate system and reference viewpoint.
4. Which elements are real, interpreted, conceptual or unverified.
5. Timing, if known.
6. Data color conventions and comparisons, if any.
7. Key client question for each state.

When mechanics are unclear, **pause artistic invention**, clarify with Skill 04, then resume SVG work.

## Procedure

### 1. Extract story states
Select the smallest set of static moments that covers the core mechanism:
`context → first action → response → repeated action → accumulated output`.

For an integrated multi-stage physical object, teach separate stages and then show the **one assembled body**, explicitly explaining that all sections may operate concurrently as material moves through them.

### 2. Make a stable panel plan
For each panel define:
- **ID:** `S03-P02` or `03_02_actual_geometry.svg`.
- **Title:** Short and specific.
- **Single purpose:** What one relationship must be understood?
- **Before/after state:** What changed from the last panel?
- **Required elements:** Only objects necessary to demonstrate the mechanism.
- **Forbidden implications:** What a simplified drawing must not accidentally claim.
- **Caption:** 2–5 sentences, no more detail than needed.
- **Status:** Confirmed / illustrative / await client review.

### 3. Establish vector grammar
Choose simple, consistent meaning across a sequence:
- Environment: flat subdued tone and generic texture.
- Real hardware: neutral geometry/material colors.
- **Outgoing signal:** clear directional path or wavefront.
- **Returning signal:** distinct visible path back to the SAME receiver when relevant.
- **Measured point:** fixed marker attached to target/environment.
- **Accumulated output:** connected points, curves, contour, stack of profiles or flat mapped values.
- **Reference/nominal:** dashed neutral outline.
- **Actual/measured:** continuous differently colored outline.
- **Physical movement:** arrows only for confirmed physical motion.
- **Data visualization:** color encodes quantity/category and is explained in the caption; client conventions supersede aesthetics.

Don't accidentally show a measurement point rotating because the tool rotates. Don't imply perfect geometry where source describes irregular geometry.

### 4. Draw SVG directly
Use standalone SVG markup with `viewBox`, e.g. `viewBox="0 0 360 240"`, and the simplest primitives available:
- `<rect>` for background, body and panels;
- `<path>` for curved walls, arrows, flow trajectories, waveform outlines;
- `<circle>` for receivers, endpoints, points, rings;
- `<ellipse>` for section or depth cues;
- `<line>` for reference/distance guides;
- `<g>` for grouping;
- `<defs>` only for gradients that materially improve reading.

Avoid dependence on web assets, fonts, scripts, CSS frameworks or embedded HTML. Make each SVG independent and easy to save as `.svg`. Assign unique gradient IDs per standalone panel to prevent collisions if later combined.

### 5. Present panel with caption outside
Use exactly this general structure (no compulsory elaborate formatting):

**Panel 2 — Echo returns**  
*Time: 0:13–0:15 (if known)*

`[inline SVG frame]`

**Caption for client:**  
The transmitted pulse reflects from the wall and returns to the same sensor. The elapsed time can be used to determine a distance. This image is a conceptual visualization of ultrasound, not emitted visible light.

If one critical unknown remains, include **Client confirmation needed:** [one question].

### 6. Check the frames before sending
**Mechanics:** actor, target, contact point, path, direction, timing and result are correct.

**State continuity:** counts/identities and viewpoint are consistent; persistent measurements remain in target/world coordinates.

**Drawing:** no text inside, self-contained SVG, legible phone-size, no malformed elements or invisible paths.

**Communication:** each caption teaches the event without relying on the prior panel's caption. Real vs interpreted is explicit.

**Data:** nominal vs actual is not inverted; no false physical color or case attribution.

If a diagram is wrong, simplify; don't mask wrong mechanics with finishing.

### 7. Accept client corrections as minimal changes
Classify feedback:
- Technical truth (wrong cause, position, physics, direction).
- Narrative learning (right mechanism, wrong explanation order).
- Geometry/reference (shape, placement, scale).
- Visualization convention (colors, axis, measured-point display).
- Aesthetics/finishing (light, shadows, material appearance).

Modify **only the affected panel(s)** and downstream states dependent on them. Preserve existing panel IDs, approved panels and client decisions. State exactly what changed and why. When a correction changes the mechanism, rerun Skill 04 locally before redrawing.

### 8. Package for Padlet or other client collaboration, when needed
Deliver independent, numbered items:
- `S03_01_reference.svg`, `S03_01_reference.png` (optional convenience preview)
- `S03_02_actual.svg`, `S03_02_actual.png`
- `...`
- `CAPTIONS.md` containing each short client caption and the section intro.
- Optional preview sheet and `.zip` package.

A storyboard column should contain **one post per panel** so the client can comment on a specific mechanic. A normal document can be supplied if explicitly preferred, but is not the default for rapid collaboration.

Ensure any sandbox download paths have actually been created and verified. If output is only in chat, do not fabricate file links.

### 9. Handoff after approval
Provide:
- Approved panel IDs and revision numbers.
- What is physically fixed: component identities, flow directions, source/return interactions, positions, shape and data semantics.
- What may be creatively changed: lens, set dressing, lighting, materials, framing, animation speed and visual effects (within technical constraints).
- Source images/CAD required for product-accurate final shots.
- Open questions and approver.

These are **mechanism storyboards**, not polished animation frames, CAD drawings or final rendering specifications.

## Reusable patterns

### Pulse → echo → point → ring
1. Outgoing wavefront from one receiver/emitter.
2. Wall contact, then visible echo returns to that same location.
3. Persistent measurement point at the wall.
4. Rotation/repeated measurements accumulate points around circumference.

### Intended vs actual shape
1. Nominal boundary as dashed reference.
2. Actual irregular measured boundary in continuous stroke; reveal deviation areas.
3. Stack cross-sections through depth to indicate 3D geometry.

### One input, two measurements
1. Show one input event/waveform.
2. Show first measured property and its output.
3. Return to the same source waveform.
4. Show second measured property and its distinct output.

Never present property B as a transformation of property A if they derive independently.

### Integrated mechanism
1. Separate simplified diagrams for functions A, B, C.
2. Complete object overview showing the physical shapes together.
3. Caption makes clear which effects are simultaneous versus sequential flow exposure.

### Concept → proof
1–4. Stylized, uncluttered representations that communicate principles.
5. One actual verified product/report/image only where permission and attribution exist.

## Quality gate
A section passes when:
- User and client can point to and correct individual events.
- Every panel has one clear causal lesson.
- SVGs are fast to revise, readable, and normally have no text.
- Captions are standalone and scientifically/technically cautious.
- The drawings do not invent details or misattribute real evidence.
- A future animator can understand what physically must happen from panels + captions alone.

## Fast mode — must be genuinely fast
If the user says **"next section as SVGs in chat"**, do this with no unnecessary questions:
1. Outline 3–5 meaningful states.
2. Show each as a compact SVG in chat.
3. Follow immediately with the corresponding caption.
4. Give a short section introduction for client paste.
5. Keep all optional rendering/export work out of the way until requested.

**Do not automatically create** photoreal images, HTML pages, complex vector scenes, cinematic lighting references or final artwork. SVG is the working surface, not a requirement to build a separate tool.
